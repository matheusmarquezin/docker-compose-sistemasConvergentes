var Cliente = require("../model/Cliente.js");

var ObjectId = require('mongodb').ObjectID;

class ClienteDAO {

    constructor(connection) {
        this.connection = connection;
    }
    getClientes(cb){
        this.connection.collection("cliente").find({}).toArray(function (err, clientes) {
            return cb(err,clientes);
        });
    }

    getClienteById(id, cb) {
        this.connection.collection("cliente").findOne({ "_id": ObjectId(id) }, function (err, clienteBanco) {
            cb(err,new Cliente(clienteBanco))
        });
    }
    getClienteByEmail(email, cb) {
        this.connection.collection("cliente").findOne({"email": email }, function (err, clienteBanco) {
           cb(err,new Cliente(clienteBanco))
        });
    }
    getClienteByEmailAndPassword(email,password, cb) {
        this.connection.collection("cliente").findOne({"email": email,"password":password }, function (err, clienteBanco) {
           cb(err,new Cliente(clienteBanco))
        });
    }
    addCliente(cliente, cb) {
        this.connection.collection("cliente").insertOne(cliente.getClienteDb(), function (err, res) {
            cb(err, res.ops[0]._id)
        });
    }

    updateCliente(cliente, cb) {
        this.connection.collection("cliente").updateOne({ "_id": ObjectId(cliente._id) }, cliente.getClienteDb(), function (err, res) {
            cb(err,res);
        });
    }
    removeCliente(id, cb) {
        this.connection.collection("cliente").remove({ "_id": ObjectId(id) }, 1).then(function (err, res) {
            console.log(err)
            if (err)
                return cb(null);
            else
                return cb(res);
        });
    }
    // getClientes(cb) {
    //     var clientes = [];
    //     this.connection.connect();
    //     try {
    //         this.connection.query('SELECT * FROM cliente', function (error, results, fields) {
    //             if (error) throw error;
    //             console.log(results)
    //             for(var clienteBanco in results){
    //                 console.log(new Cliente(results[clienteBanco]))
    //                 clientes.push(new Cliente(results[clienteBanco]))
    //             }
    
    //             return cb(clientes);
    //         });
    //     } catch (error) {
    //         cb(error)
    //     } finally{
    //         this.connection.end();
    //     }
      

    // }
}
module.exports = ClienteDAO;