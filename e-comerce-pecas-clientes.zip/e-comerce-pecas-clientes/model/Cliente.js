class Cliente {
    constructor(cliente) {
        var _id;
        var nome;
        var email;
        var dataCadastro;
        var password;
        var carrinho;
        var pedidos;

        if (cliente) {
            this._id = cliente._id;
            this.nome = cliente.nome;
            this.email = cliente.email;
            this.password = cliente.password;
            this.carrinho = cliente.carrinho;
            this.pedidos = cliente.pedidos;
            this.dataCadastro = cliente.dataCadastro;
        }

    }

    getClienteDb() {
        return {
            "nome":this.nome,
            "email": this.email, "password": this.password, "carrinho": this.carrinho,
            "pedidos": this.pedidos, "dataCadastro": this.dataCadastro };
    }
}

module.exports = Cliente;