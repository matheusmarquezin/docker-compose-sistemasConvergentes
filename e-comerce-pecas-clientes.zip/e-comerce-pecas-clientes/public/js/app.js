var app = angular.module('aplicativo', []);
app.controller('index', function ($scope) {
    $scope.teste = "";
});