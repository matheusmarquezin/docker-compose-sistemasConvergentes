var express = require('express');
var router = express.Router();
var clienteDAO;

var Cliente = require("../model/Cliente.js");

router.use(function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
  res.header('Access-Control-Allow-Methods', 'PUT, POST, GET, DELETE, OPTIONS');
  next();
});

router.all('*', function (req, res, next) {
  if (!clienteDAO) {
    var Dao = require("../dao/ClienteDAO.js");
    if (req.app.settings.mysqldb) {
      // clienteDAO = new Dao(req.app.settings.mysqldb)
      clienteDAO = new Dao(req.app.settings.mongo)
    } else
      return res.send(500)
  }
  return next()
});

/* GET home page. */
router.get('/', function (req, res, next) {
  next();
});
router.get('/clientes', function (req, res, next) {
  clienteDAO.getClientes((err, dados) => {
    if (!err)
      res.send(dados)
    else
      res.send(err, 400);
  });
});
router.get('/login/:email/:password', function (req, res, next) {
  clienteDAO.getClienteByEmailAndPassword(req.param("email"),req.param("password"), (err, cliente) => {
    if (!err)
      res.send(cliente)
    else
      res.send(err, 400);
  });
});
router.get('/cliente/:id', function (req, res, next) {
  clienteDAO.getClienteById(req.param("id"), (err, cliente) => {
    if (!err)
      res.send(cliente)
    else
      res.send(err, 400);
  });
});
router.get('/cliente/cod/:id', function (req, res, next) {
  clienteDAO.getClienteByCodigo(req.param("id"), (err, cliente) => {
    if (!err)
      res.send(cliente)
    else
      res.send(err, 400);
  });
});
router.post('/inserirCliente', function (req, res, next) {
  var cliente = new Cliente(req.body);

  clienteDAO.addCliente(cliente, (err, retorno) => {
    if (!err)
      res.send(retorno)
    else
      res.send(err, 400);
  });
});

router.put('/alterarCliente', function (req, res, next) {
  var clienteModificado = new Cliente(req.body);
  console.log(clienteModificado)
  clienteDAO.updateCliente(clienteModificado, (err, response) => {
    if (!err)
      res.send(response)
    else
      res.send(err, 400);
  });
});

router.delete('/deletarCliente/:id', function (req, res, next) {
  clienteDAO.removeCliente(req.param("id"), (err, resposta) => {
    if (!err)
      return res.send(resposta)
    else
      return res.send(err, 200)
  })
});


module.exports = router;
