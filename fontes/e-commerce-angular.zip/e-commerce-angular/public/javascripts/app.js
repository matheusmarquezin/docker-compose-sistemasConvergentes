var app = angular.module('ecommerce', ["ngRoute", "ngCookies"]);

app.config(function ($routeProvider) {
    $routeProvider
        .when("/", {
            templateUrl: "../pages/home.htm",
            controller: "home"
        }).when("/produto/:id", {
            templateUrl: "../pages/item.htm",
            controller: "item"
        }).when("/login", {
            templateUrl: "../pages/login.htm",
            controller: "login"
        }).when("/logout", {
            templateUrl: "../pages/login.htm",
            controller: "logout"
        }).when("/carrinho", {
            templateUrl: "../pages/carrinho.htm",
            controller: "carrinho"
        }).when("/pedido", {
            templateUrl: "../pages/pedido.htm",
            controller: "pedido"
        }).when("/pedido/:id", {
            templateUrl: "../pages/pedidoItem.htm",
            controller: "pedidoItem"
        });
});
app.controller('home', function ($scope, $http, $location, $cookies, $rootScope) {

    if (!$cookies.get('user')) {
        console.log($cookies.get('user'))
        $location.url('/login')
    } else {
        $rootScope.logado = true
    }
    $http({
        method: 'GET',
        url: 'http://localhost:4000/produtos'
    }).then(function successCallback(response) {
        $scope.produtos = response.data;
    }, function errorCallback(response) {
    });
});
app.controller('item', function ($scope, $http, $routeParams, $location, $rootScope, $cookies) {
    $scope.quantidade = 1;
    if (!$cookies.get('user')) {
        $location.url('/login')
    } else {
        $rootScope.logado = true
    }
    $http({
        method: 'GET',
        url: 'http://localhost:4000/produto/' + $routeParams.id
    }).then(function successCallback(response) {
        $scope.produto = response.data;
    }, function errorCallback(response) {
    });
    $scope.adicionarAoCarrinho = (produto) => {
        var usuario = JSON.parse($cookies.get('user').toString())

        if (!usuario.carrinho) {
            usuario.carrinho = [];
        }

        usuario.carrinho.push({ "quantidade": $scope.quantidade, "produto": produto })

        $cookies.put('user', JSON.stringify(usuario))
        alert("Adicionado com sucesso!")
    }

});
app.controller('login', function ($scope, $http, $routeParams, $location, $rootScope, $cookies) {
    if (!$cookies.get('user')) {
        $location.url('/login')
    } else {
        $rootScope.logado = true
    }
    $scope.login = () => {
        $http({
            method: 'GET',
            url: 'http://localhost:3005/login/' + $scope.email + '/' + $scope.password
        }).then(function successCallback(response) {
            $cookies.put("user", JSON.stringify(response.data))
            $location.url('/')
            $rootScope.logado = true;
            console.log(response.data)
        }, function errorCallback(response) {
        });
    }
});
app.controller('logout', function ($scope, $http, $routeParams, $location, $rootScope, $cookies) {
    $cookies.remove("user")
    $location.url('/login')
    $rootScope.logado = false;
});
app.controller('carrinho', function ($scope, $http, $routeParams, $location, $rootScope, $cookies) {
    if (!$cookies.get('user')) {
        $location.url('/login')
    } else {
        $rootScope.logado = true
    }
    $scope.usuario = JSON.parse($cookies.get("user"))
    $scope.selecionarItem = (index) => {
        $scope.index = index;
    }
    $scope.removerItem = (item) => {
        $scope.usuario.carrinho.splice($scope.index, 1);
        $cookies.put('user', JSON.stringify($scope.usuario))
    }
    $scope.comprar = () => {
        if ($scope.usuario.carrinho.length > 0)
            $http({
                method: 'POST',
                url: 'http://localhost:3002/venda',
                data: $scope.usuario
            }).then(function successCallback(response) {
                $scope.usuario.carrinho = [];
                if (!$scope.usuario.compras)
                    $scope.usuario.compras = []
                $scope.usuario.compras.push(response.data)
                $http({
                    method: 'PUT',
                    url: 'http://localhost:3005/alterarCliente',
                    data: $scope.usuario
                }).then(function successCallback(response) {
                    $cookies.put('user', JSON.stringify($scope.usuario))
                    alert("Compra efetuada com sucesso!")
                    $location.url("/pedido")
                    console.log($scope.usuario)
                }, function errorCallback(response) {
                });
            }, function errorCallback(response) {
                alert(response.data.menssage)
            });
    }
});
app.controller('pedido', function ($scope, $http, $routeParams, $location, $rootScope, $cookies) {
    if (!$cookies.get('user')) {
        $location.url('/login')
    } else {
        $rootScope.logado = true
    }
    $scope.usuario = JSON.parse($cookies.get("user"))
    $http({
        method: 'GET',
        url: 'http://localhost:3002/pedido'
    }).then(function successCallback(response) {
        $scope.pedidos = []
        for (item in response.data) {
            var it = JSON.parse(response.data[item]);
            if ($scope.usuario._id == it.codigoCliente) {
                $scope.pedidos.push(it);
            }
        }
    }, function errorCallback(err) {
        alert(err.menssage)
    });
});
app.controller('pedidoItem', function ($scope, $http, $routeParams, $location, $rootScope, $cookies) {
    if (!$cookies.get('user')) {
        $location.url('/login')
    } else {
        $rootScope.logado = true
    }
    $http({
        method: 'GET',
        url: 'http://localhost:3002/pedido/' + $routeParams.id
    }).then(function successCallback(response) {
        $scope.pedido = response.data;
        $scope.buscarItens();
    }, function errorCallback(err) {
        alert(err.menssage) 
        for (item in response.data) {
            var it = JSON.parse(response.data[item]);
            if ($scope.usuario._id == it.codigoCliente) {
                $scope.pedidos.push(it);
            }
        }
    });
    $scope.buscarItens = () => {
        $http({
            method: 'GET',
            url: 'http://localhost:3002/itensPedidosList/'+$routeParams.id
        }).then(function successCallback(response) {
            $scope.pedidoItens =[]
            for (item in response.data) {
                var it = JSON.parse(response.data[item]);
                $scope.pedidoItens.push(it);
            }
        }, function errorCallback(err) {
            alert(err.menssage)
        });
    }
    $scope.voltar = () =>{
        $location.url("/pedido")
    }
});